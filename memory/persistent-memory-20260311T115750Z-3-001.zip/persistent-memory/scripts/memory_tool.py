import sys
import urllib.request
import json
import argparse

MEMORY_SERVER_URL = "http://localhost:5050"

def ingest_memory(text):
    print(f"🧠 [Persistent Memory] Storing: '{text}'...", file=sys.stderr)
    try:
        data = json.dumps({'text': text}).encode('utf-8')
        req = urllib.request.Request(f'{MEMORY_SERVER_URL}/ingest', data=data, headers={'Content-Type': 'application/json'})
        response = urllib.request.urlopen(req, timeout=10)
        result = json.loads(response.read().decode('utf-8'))
        print(f"✅ Success: {result.get('result', 'Stored.')}")
    except Exception as e:
        print(f"❌ Error storing memory: {str(e)}", file=sys.stderr)
        sys.exit(1)

def query_memory(question):
    print(f"🧠 [Persistent Memory] Querying: '{question}'...", file=sys.stderr)
    try:
        data = json.dumps({'question': question}).encode('utf-8')
        req = urllib.request.Request(f'{MEMORY_SERVER_URL}/query', data=data, headers={'Content-Type': 'application/json'})
        response = urllib.request.urlopen(req, timeout=30)
        result = json.loads(response.read().decode('utf-8'))
        
        mem_text = result.get('result', '')
        if mem_text:
            print("\n" + "="*50)
            print("💡 MEMORY RESULT:")
            print(mem_text)
            print("="*50 + "\n")
        else:
            print("❌ No relevant memories found.", file=sys.stderr)
    except Exception as e:
        print(f"❌ Error querying memory: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="LUCA Persistent Memory CLI Client (Always-On ADK)")
    subparsers = parser.add_subparsers(dest="action", required=True)

    ingest_parser = subparsers.add_parser("ingest", help="Store a new memory.")
    ingest_parser.add_argument("text", help="The text to remember.")

    query_parser = subparsers.add_parser("query", help="Query the persistent memory.")
    query_parser.add_argument("question", help="The question to ask the memory bank.")

    args = parser.parse_args()

    if args.action == "ingest":
        ingest_memory(args.text)
    elif args.action == "query":
        query_memory(args.question)
