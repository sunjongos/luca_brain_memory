---
name: persistent-memory
description: (CRITICAL) Access the Always-On ADK Persistent Memory store to remember user preferences, context, and project goals across sessions. Any agent (Antigravity/Claude Code/OpenClaw) MUST use this.
---

# 🧠 Persistent Memory Skill (Always-On ADK)

You (the AI Agent: Antigravity, Claude Code, or OpenClaw) are now directly connected to the CEO's **Always-On Persistent Memory (ADK) Server**. Since your normal conversation context gets cleared when a new session starts, you **MUST** use this tool to remember and recall important facts about the user, the business (ex: Namyangju Baek Hospital, Doctor Eye), marketing strategies, or coding preferences.

## 📥 1. Storing Memory (Ingestion)
Whenever the user tells you an important preference, workflow rule, or project goal that you should NOT forget in future conversations, you must save it to the ADK database.

**Command Syntax:**
```bash
python "C:\Users\USER\.claude\skills\persistent-memory\scripts\memory_tool.py" ingest "<텍스트>"
```

**Example Usage:**
```bash
python "C:\Users\USER\.claude\skills\persistent-memory\scripts\memory_tool.py" ingest "CEO prefers Next.js over Vanilla JS for all new dashboard frontend projects."
```

## 🔍 2. Querying Memory (Recall)
When you start a new task, or if the user asks "do you remember...", or if you need to know the context of a project (e.g., "What was the marketing strategy for the Spine Center?"), query the memory bank. The ADK AI will search its SQLite graph and return a consolidated answer.

**Command Syntax:**
```bash
python "C:\Users\USER\.claude\skills\persistent-memory\scripts\memory_tool.py" query "<질문>"
```

**Example Usage:**
```bash
python "C:\Users\USER\.claude\skills\persistent-memory\scripts\memory_tool.py" query "What is the primary target keyword strategy for Naver Search Ads?"
```

## ⚠️ Important Rules:
1. **Always query when unsure:** If the CEO mentions a past project or preference and it's not in your immediate context window, use the `query` command before asking them.
2. **Proactive Ingestion:** Don't wait for the CEO to say "remember this". If you make a major architectural decision or learn a new constraint, `ingest` it immediately to save time in the future!
3. **Double Quotes:** Be careful to properly escape double quotes when sending JSON strings in the terminal.
4. **Prerequisite:** The `memory_server.py` must be running locally on `http://localhost:5050` (which is managed via PM2). Do not try to start the server yourself unless it is explicitly down.
